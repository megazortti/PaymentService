exports.handler = async () => {
  return {
    statusCode: 200,
    body: "Hello, world!! Teste kkk"
  };
};
